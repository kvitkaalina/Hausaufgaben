
// Создайте массив объектов с полями "name" и "price". Реализуйте функцию hasExpensiveItem, используя метод some, чтобы проверить, содержит ли массив хотя бы один объект с ценой выше 50.

const object = [
 {
    name: 'banana',
    price: 50,

},
{
    name: 'kiwi',
    price: 30,

},
{
    name: 'cherry',
    price: 50,

},
]
function hasExpensiveItem(arr) {
    return arr.some(items => items.price > 50 )
    
}
console.log(hasExpensiveItem(object));




    
